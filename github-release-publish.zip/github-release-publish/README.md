# Reusable GitHub release skill

This is a standalone Codex skill, not a Minecraft-specific script or a dependency of Prototype Core. It captures the process used to publish this project's GitHub release: try ordinary `gh` uploads, then use a temporary GitHub Actions upload job when the environment's credentials work for the API but fail on `uploads.github.com`.

## Install for other projects

For all projects on your Codex machine, put this directory at:

```text
~/.agents/skills/github-release-publish/
  SKILL.md
  scripts/prepare_runner_upload.py
  tests/test_prepare_runner_upload.py
```

From the ZIP distributed with this skill:

```sh
mkdir -p ~/.agents/skills
unzip /path/to/github-release-publish.zip -d ~/.agents/skills
```

To make it specific to one repository, extract it into that repository's `.agents/skills/` instead. Preserve any existing customized installation. Start a new Codex session if the current one has already loaded its skill catalog. Cloud containers are separate machines: installing on your computer does not automatically install it in every cloud environment; put it in each repository/environment where needed.

If your Codex client does not auto-discover filesystem skills, explicitly ask it to read `.agents/skills/github-release-publish/SKILL.md` and follow it. The procedure and helper also work this way without a plugin installation.

Ask Codex:

```text
Use $github-release-publish to publish version v1.2.3 for owner/project.
Use the project's release build and attach the installable package and checksums.
```

`SKILL.md` contains the complete procedure. The normal path needs GitHub CLI and the project's build tools. The optional preparation helper additionally needs Python 3.10+, Git, and configured Git author identity. It supports a GitHub.com `origin` using HTTPS or SSH. It is independent of Java, Minecraft, Gradle, and particular repository names or release versions.

## What the fallback does

1. The agent prepares tested artifacts and an existing draft release targeting an exact published commit.
2. The helper creates an assets-only temporary Git tree with checksums and a narrowly scoped workflow. It leaves HEAD, the real index, and local changes alone. It does not push or publish.
3. The agent pushes that prepared commit to its unique temporary branch.
4. GitHub's runner uses its own repository-scoped `github.token` to verify/upload assets. No personal token is recovered from the cloud proxy. Existing project workflows are not included in the temporary tree.
5. The agent verifies uploaded digests, publishes the draft, checks the release/tag, and removes only its own temporary branch after the job completes.

This requires permission to push workflows and run Actions with release-asset write access. It does not grant those permissions or override restrictions. The Git payload fallback is limited to 95 MiB per selected asset; larger artifacts need ordinary upload authentication or a suitable build workflow. Only files already authorized for publication belong in the temporary Git payload, because deleting its branch does not erase history or workflow retention.

## Test locally without publishing

Run from this skill directory on Linux with Bash and `sha256sum` (the same tools as the generated Ubuntu runner):

```sh
python3 -B -m unittest discover -s tests -v
```

The tests use temporary local repositories and a fake `gh` executable. They check preservation of local changes, payload isolation, filename/tag handling, checksum verification, duplicate/conflicting assets, draft protection, and the generated runner's behavior. They do not push branches, upload files, use a real token, or create releases.
