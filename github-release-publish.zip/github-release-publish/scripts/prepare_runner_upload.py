#!/usr/bin/env python3
"""Prepare an isolated GitHub release upload commit. Never pushes or publishes."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from urllib.parse import urlsplit
import uuid

MAX_ASSET_BYTES = 95 * 1024 * 1024
REPO_PATTERN = re.compile(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")
ASSET_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._+-]*")
CHECKOUT_SHA = "11bd71901bbe5b1630ceea73d27597364c9af683"  # actions/checkout v4.2.2


def git(*arguments: str, env: dict[str, str] | None = None, data: bytes | None = None) -> str:
    result = subprocess.run(
        ["git", *arguments], input=data, capture_output=True, env=env, check=True
    )
    return result.stdout.decode().strip()


def github_origin(value: str) -> str:
    if value.startswith("git@github.com:"):
        path = value.removeprefix("git@github.com:")
    else:
        parsed = urlsplit(value)
        if parsed.scheme not in {"https", "ssh"} or parsed.hostname != "github.com":
            raise ValueError("origin must identify a GitHub.com repository via HTTPS or SSH")
        path = parsed.path.lstrip("/")
    path = path.removesuffix(".git")
    if not REPO_PATTERN.fullmatch(path):
        raise ValueError("Cannot determine an unambiguous owner/repository from origin")
    return path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def workflow(branch: str, tag: str, target: str, release_id: int,
             payload: str, names: list[str]) -> str:
    # Values use JSON quoting, which is also valid YAML quoting. None is shell code.
    environment = {
        # Encoding prevents GitHub expression syntax in a valid Git tag from being evaluated.
        "RELEASE_TAG_BASE64": base64.b64encode(tag.encode()).decode(),
        "RELEASE_ID": str(release_id),
        "EXPECTED_COMMIT": target,
        "PAYLOAD_DIR": payload,
        "ASSET_NAMES": json.dumps(names),
    }
    lines = [
        "name: Upload prepared release assets",
        "on:",
        "  push:",
        "    branches: " + json.dumps([branch]),
        "permissions:",
        "  contents: write",
        "jobs:",
        "  upload:",
        "    runs-on: ubuntu-latest",
        "    timeout-minutes: 10",
        "    steps:",
        f"      - uses: actions/checkout@{CHECKOUT_SHA}",
        "        with:",
        "          persist-credentials: false",
        "      - name: Verify prepared files and upload missing assets to the draft",
        "        env:",
        "          GH_TOKEN: ${{ github.token }}",
    ]
    lines += ["          " + key + ": " + json.dumps(value)
              for key, value in environment.items()]
    lines += [
        "        run: |",
        '          cd "$PAYLOAD_DIR"',
        "          sha256sum --check SHA256SUMS",
        "          python3 - <<'PY'",
    ]
    runner = '''import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess

repo = os.environ["GITHUB_REPOSITORY"]
tag = base64.b64decode(os.environ["RELEASE_TAG_BASE64"]).decode()
release_id = os.environ["RELEASE_ID"]
endpoint = f"repos/{repo}/releases/{release_id}"

def release():
    return json.loads(subprocess.run(
        ["gh", "api", endpoint], check=True, capture_output=True, text=True).stdout)

def expected(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()

def matches(asset, path):
    return (asset["state"] == "uploaded" and asset["size"] == path.stat().st_size
            and asset.get("digest") == expected(path))

names = json.loads(os.environ["ASSET_NAMES"])
paths = [Path(name) for name in names]
for path in paths:
    current = release()
    if (not current["draft"] or current["tag_name"] != tag
            or current["target_commitish"] != os.environ["EXPECTED_COMMIT"]):
        raise SystemExit("Release is no longer the intended draft/commit; refusing upload")
    existing = {asset["name"]: asset for asset in current["assets"]}
    if path.name in existing:
        if not matches(existing[path.name], path):
            raise SystemExit("Conflicting existing release asset: " + path.name)
        print("Already verified:", path.name)
        continue
    subprocess.run(["gh", "release", "upload", "--repo", repo, tag, str(path)], check=True)

uploaded = {asset["name"]: asset for asset in release()["assets"]}
for path in paths:
    if path.name not in uploaded or not matches(uploaded[path.name], path):
        raise SystemExit("Upload checksum verification failed: " + path.name)
    print("Verified upload:", path.name)
'''
    lines += ["          " + line if line else "" for line in runner.splitlines()]
    lines += ["          PY", ""]
    return "\n".join(lines)


def prepare(args: argparse.Namespace) -> dict:
    if not REPO_PATTERN.fullmatch(args.repo):
        raise ValueError("--repo must be owner/repository")
    if args.release_id <= 0:
        raise ValueError("--release-id must be a positive numeric draft release ID")
    if not args.tag or args.tag.startswith("-"):
        raise ValueError("--tag must be a valid tag name, not an option")
    git("check-ref-format", "refs/tags/" + args.tag)
    root = Path(git("rev-parse", "--show-toplevel")).resolve()
    if github_origin(git("config", "--get", "remote.origin.url")).lower() != args.repo.lower():
        raise ValueError("Requested repository does not match origin; refusing preparation")
    target = git("rev-parse", "--verify", "--end-of-options", args.target + "^{commit}")
    if not re.fullmatch(r"[a-f0-9]{40}", target):
        raise ValueError("Expected a full GitHub SHA-1 source commit")

    output = Path(args.output_dir).expanduser().resolve()
    git_directory = Path(git("rev-parse", "--absolute-git-dir")).resolve()
    common_git_directory = Path(git("rev-parse", "--git-common-dir")).resolve()
    if (output.is_relative_to(root) or output.is_relative_to(git_directory)
            or output.is_relative_to(common_git_directory)):
        raise ValueError("Choose an output directory outside the checkout and Git metadata")
    for name in ["plan.json", "SHA256SUMS"]:
        if (output / name).exists():
            raise ValueError("Output already contains " + name + "; choose a fresh directory")

    assets = []
    seen = set()
    for value in args.asset:
        original = Path(value).expanduser()
        if original.is_symlink() or not original.is_file():
            raise ValueError("Every asset must be an existing regular file, not a symlink")
        path = original.resolve()
        name = path.name
        if not ASSET_PATTERN.fullmatch(name):
            raise ValueError("Asset basenames must be plain filenames without spaces or shell syntax")
        if name.casefold() == "sha256sums" or name.casefold() in seen:
            raise ValueError("Asset basenames must be unique; SHA256SUMS is generated")
        if path.stat().st_size > MAX_ASSET_BYTES:
            raise ValueError("Runner Git payloads support at most 95 MiB per asset; use normal upload authentication or a build workflow")
        seen.add(name.casefold())
        assets.append({"path": str(path), "name": name, "bytes": path.stat().st_size,
                       "sha256": sha256(path)})
    if not assets:
        raise ValueError("Select at least one release artifact")
    assets.sort(key=lambda item: item["name"])
    checksum_data = "".join(f'{item["sha256"]}  {item["name"]}\n' for item in assets).encode()
    nonce = uuid.uuid4().hex[:12]
    slug = re.sub(r"[^a-zA-Z0-9._-]", "-", args.tag).strip(".-")[:48] or "release"
    branch = f"codex/release-upload-{slug}-{nonce}"
    payload = f".codex-release-assets/{nonce}"
    workflow_path = f".github/workflows/codex-release-upload-{nonce}.yml"
    names = [item["name"] for item in assets] + ["SHA256SUMS"]
    workflow_data = workflow(branch, args.tag, target, args.release_id, payload, names).encode()

    # An assets-only temporary tree avoids copying/running the project's existing push workflows.
    # The published source remains its explicit parent; real HEAD/index/worktree are untouched.
    with tempfile.TemporaryDirectory(prefix="codex-release-index-") as temporary:
        environment = os.environ.copy()
        environment["GIT_INDEX_FILE"] = str(Path(temporary) / "index")
        git("read-tree", "--empty", env=environment)
        for asset in assets:
            blob = git("hash-object", "-w", "--no-filters", "--", asset["path"], env=environment)
            git("update-index", "--add", "--cacheinfo", "100644", blob,
                payload + "/" + asset["name"], env=environment)
        for path, contents in [(payload + "/SHA256SUMS", checksum_data),
                               (workflow_path, workflow_data)]:
            blob = git("hash-object", "-w", "--stdin", env=environment, data=contents)
            git("update-index", "--add", "--cacheinfo", "100644", blob, path, env=environment)
        tree = git("write-tree", env=environment)
        commit = git("commit-tree", tree, "-p", target, env=environment,
                     data=("Prepare verified release asset upload for " + args.tag + "\n").encode())

    output.mkdir(parents=True, exist_ok=True)
    with (output / "SHA256SUMS").open("xb") as stream:
        stream.write(checksum_data)
    checksum_asset = {"path": str(output / "SHA256SUMS"), "name": "SHA256SUMS",
                      "bytes": len(checksum_data), "sha256": hashlib.sha256(checksum_data).hexdigest()}
    plan = {"repo": args.repo, "tag": args.tag, "target_commit": target,
            "release_id": args.release_id, "branch": branch, "commit": commit,
            "workflow_path": workflow_path, "payload_directory": payload,
            "assets": assets + [checksum_asset], "pushed": False, "published": False}
    with (output / "plan.json").open("x", encoding="utf-8") as stream:
        json.dump(plan, stream, indent=2)
        stream.write("\n")
    return plan


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--target", required=True, help="The intended, already published source commit")
    parser.add_argument("--release-id", type=int, required=True, help="Existing numeric draft release ID")
    parser.add_argument("--asset", action="append", required=True)
    parser.add_argument("--output-dir", required=True, help="Fresh directory outside the checkout")
    args = parser.parse_args()
    try:
        plan = prepare(args)
    except subprocess.CalledProcessError as failure:
        # Git does not need token values; do not dump environment or credential files on failure.
        print("Git preparation failed: " + failure.stderr.decode(errors="replace").strip(), file=sys.stderr)
        return 1
    except (ValueError, OSError) as failure:
        print(str(failure), file=sys.stderr)
        return 1
    print(json.dumps(plan, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
