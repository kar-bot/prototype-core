"""Local regression tests using temporary Git repos and fake gh, never real releases."""

import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/prepare_runner_upload.py"


class PrepareRunnerUploadTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="release-skill-test-")
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.repo = self.base / "repo"
        self.repo.mkdir()
        self.git("init", "--quiet", "--initial-branch=main")
        self.git("config", "user.name", "Release Helper Test")
        self.git("config", "user.email", "test@example.invalid")
        self.git("remote", "add", "origin", "https://github.com/example/project.git")
        (self.repo / "README.md").write_text("Original project source\n")
        workflows = self.repo / ".github/workflows"
        workflows.mkdir(parents=True)
        (workflows / "existing-project-job.yml").write_text("name: Must not be copied to release payload\n")
        self.git("add", ".")
        self.git("commit", "--quiet", "-m", "Initial source")
        self.target = self.git("rev-parse", "HEAD")
        self.asset = self.base / "package.zip"
        self.asset.write_bytes(b"Test release bytes\x00\xff\n")
        self.output = self.base / "plan"

    def git(self, *arguments):
        return subprocess.run(["git", *arguments], cwd=self.repo, check=True,
                              capture_output=True, text=True).stdout.strip()

    def run_helper(self, *, assets=None, repo="example/project", tag="v1.2.3",
                   target=None, release_id="12345", output=None):
        command = [sys.executable, str(SCRIPT), "--repo", repo, "--tag", tag,
                   "--target", target or self.target, "--release-id", release_id,
                   "--output-dir", str(output or self.output)]
        for asset in assets if assets is not None else [self.asset]:
            command += ["--asset", str(asset)]
        return subprocess.run(command, cwd=self.repo, capture_output=True, text=True)

    def successful_plan(self, **arguments):
        result = self.run_helper(**arguments)
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def workflow(self, plan):
        return self.git("show", plan["commit"] + ":" + plan["workflow_path"])

    def run_generated_job(self, plan, *, existing=None, draft=True, target=None, tag=None,
                          corrupt_payload=False):
        """Execute the emitted job with a local fake gh, never GitHub or a real token."""
        workspace = Path(tempfile.mkdtemp(prefix="runner-", dir=self.base))
        for name in self.git("ls-tree", "-r", "--name-only", plan["commit"]).splitlines():
            path = workspace / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(subprocess.run(["git", "show", plan["commit"] + ":" + name],
                             cwd=self.repo, check=True, capture_output=True).stdout)
        if corrupt_payload:
            (workspace / plan["payload_directory"] / self.asset.name).write_bytes(b"Damaged after preparation")
        state = workspace / "fake-release.json"
        state.write_text(json.dumps({"draft": draft, "tag_name": tag or plan["tag"],
                         "target_commitish": target or plan["target_commit"],
                         "assets": existing or [], "uploads": []}))
        executable = workspace / "bin/gh"
        executable.parent.mkdir()
        executable.write_text("#!" + sys.executable + "\n" + '''import hashlib
import json
import os
from pathlib import Path
import sys
state = Path(os.environ["FAKE_RELEASE_STATE"])
release = json.loads(state.read_text())
args = sys.argv[1:]
if args[0] == "api":
    assert args == ["api", "repos/example/project/releases/12345"]
    print(json.dumps(release))
elif args[:2] == ["release", "upload"]:
    assert args[2:5] == ["--repo", "example/project", release["tag_name"]]
    assert len(args) == 6
    path = Path(args[5])
    assert path.name not in {asset["name"] for asset in release["assets"]}
    release["uploads"].append(path.name)
    release["assets"].append({"name": path.name, "size": path.stat().st_size,
        "state": "uploaded", "digest": "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()})
    state.write_text(json.dumps(release))
else:
    raise SystemExit("Unsupported fake operation; tests cannot publish or access GitHub")
''')
        executable.chmod(0o755)
        environment = os.environ.copy()
        environment.update({"PATH": str(executable.parent) + os.pathsep + environment["PATH"],
            "GH_TOKEN": "test-placeholder-never-a-real-token", "GITHUB_REPOSITORY": "example/project",
            "RELEASE_ID": str(plan["release_id"]), "EXPECTED_COMMIT": plan["target_commit"],
            "RELEASE_TAG_BASE64": base64.b64encode(plan["tag"].encode()).decode(),
            "ASSET_NAMES": json.dumps([asset["name"] for asset in plan["assets"]]),
            "PAYLOAD_DIR": plan["payload_directory"], "FAKE_RELEASE_STATE": str(state)})
        body = textwrap.dedent(self.workflow(plan).split("        run: |\n", 1)[1])
        result = subprocess.run(["bash", "-e", "-o", "pipefail", "-c", body], cwd=workspace,
                                env=environment, capture_output=True, text=True)
        return result, json.loads(state.read_text())

    def test_prepares_exact_artifacts_checksums_and_source_parent_without_remote_actions(self):
        plan = self.successful_plan()
        self.assertEqual(plan["target_commit"], self.target)
        self.assertEqual(self.git("rev-parse", plan["commit"] + "^"), self.target)
        self.assertFalse(plan["pushed"])
        self.assertFalse(plan["published"])
        self.assertEqual(self.git("branch", "--format=%(refname:short)"), "main")
        expected = hashlib.sha256(self.asset.read_bytes()).hexdigest()
        self.assertEqual(plan["assets"][0]["sha256"], expected)
        self.assertEqual((self.output / "SHA256SUMS").read_text(), expected + "  package.zip\n")
        self.assertEqual(json.loads((self.output / "plan.json").read_text()), plan)
        content = subprocess.run(["git", "show", plan["commit"] + ":" +
                                  plan["payload_directory"] + "/package.zip"], cwd=self.repo,
                                 check=True, capture_output=True).stdout
        self.assertEqual(content, self.asset.read_bytes())

    def test_preserves_head_index_staged_unstaged_and_untracked_user_files(self):
        (self.repo / "README.md").write_text("Staged user change\n")
        self.git("add", "README.md")
        (self.repo / "README.md").write_text("Unstaged user change\n")
        (self.repo / "user-note.txt").write_text("Untracked work\n")
        before = [self.git("rev-parse", "HEAD"), self.git("write-tree"),
                  self.git("status", "--porcelain"), self.git("diff"), self.git("diff", "--cached")]
        self.successful_plan()
        after = [self.git("rev-parse", "HEAD"), self.git("write-tree"),
                 self.git("status", "--porcelain"), self.git("diff"), self.git("diff", "--cached")]
        self.assertEqual(before, after)
        self.assertEqual((self.repo / "user-note.txt").read_text(), "Untracked work\n")

    def test_temporary_tree_does_not_copy_existing_project_workflows(self):
        plan = self.successful_plan()
        files = self.git("ls-tree", "-r", "--name-only", plan["commit"]).splitlines()
        self.assertEqual(set(files), {plan["workflow_path"],
                         plan["payload_directory"] + "/package.zip",
                         plan["payload_directory"] + "/SHA256SUMS"})
        self.assertNotIn(".github/workflows/existing-project-job.yml", files)

    def test_runner_is_scoped_draft_only_checksum_verified_and_preserves_existing_assets(self):
        plan = self.successful_plan()
        workflow = self.workflow(plan)
        self.assertIn("permissions:\n  contents: write", workflow)
        self.assertIn("persist-credentials: false", workflow)
        self.assertIn("sha256sum --check SHA256SUMS", workflow)
        self.assertIn('not current["draft"]', workflow)
        self.assertIn('current["target_commitish"]', workflow)
        self.assertIn('asset.get("digest") == expected(path)', workflow)
        self.assertIn("Conflicting existing release asset", workflow)
        self.assertNotIn("--clobber", workflow)
        self.assertNotIn("release edit", workflow)
        self.assertNotIn("release create", workflow)
        self.assertNotIn("secrets.", workflow)
        self.assertIn("GH_TOKEN: ${{ github.token }}", workflow)
        code = workflow.split("          python3 - <<'PY'\n", 1)[1].rsplit("          PY", 1)[0]
        compile(textwrap.dedent(code), "generated-runner.py", "exec")

    def test_tag_that_looks_like_github_expression_is_encoded_not_evaluated(self):
        tag = "v1.2.3-${{github.token}}"
        plan = self.successful_plan(tag=tag)
        workflow = self.workflow(plan)
        self.assertNotIn(tag, workflow)
        encoded_line = next(line for line in workflow.splitlines() if "RELEASE_TAG_BASE64:" in line)
        encoded = json.loads(encoded_line.partition(":")[2].strip())
        self.assertEqual(base64.b64decode(encoded).decode(), tag)

    def test_normal_https_and_ssh_origins_are_supported(self):
        for number, remote in enumerate(["git@github.com:example/project.git",
                                        "ssh://git@github.com/example/project.git",
                                        "https://github.com/example/project.git"]):
            with self.subTest(remote=remote):
                self.git("remote", "set-url", "origin", remote)
                self.successful_plan(output=self.base / ("plan-" + str(number)))

    def test_repository_mismatch_fails_before_writing_outputs(self):
        result = self.run_helper(repo="different/project")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("does not match origin", result.stderr)
        self.assertFalse(self.output.exists())

    def test_non_github_origin_is_rejected_without_printing_url_credentials(self):
        self.git("remote", "set-url", "origin", "https://do-not-print@example.invalid/project.git")
        result = self.run_helper()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("GitHub.com", result.stderr)
        self.assertNotIn("do-not-print", result.stdout + result.stderr)

    def test_invalid_tags_and_unresolved_commits_are_rejected(self):
        for arguments in [{"tag": "../invalid"}, {"tag": "-option"}, {"target": "does-not-exist"}]:
            with self.subTest(arguments=arguments):
                self.assertNotEqual(self.run_helper(**arguments).returncode, 0)
        self.assertFalse(self.output.exists())

    def test_invalid_repository_or_release_id_is_rejected(self):
        for arguments in [{"repo": "not-a-repository"}, {"release_id": "0"}, {"release_id": "-1"}]:
            with self.subTest(arguments=arguments):
                self.assertNotEqual(self.run_helper(**arguments).returncode, 0)

    def test_duplicate_basenames_and_generated_checksum_name_are_rejected(self):
        other = self.base / "other"
        other.mkdir()
        duplicate = other / self.asset.name
        duplicate.write_bytes(b"Different content")
        checksum = other / "SHA256SUMS"
        checksum.write_text("User-owned data")
        for assets in [[self.asset, duplicate], [checksum]]:
            with self.subTest(assets=assets):
                result = self.run_helper(assets=assets)
                self.assertNotEqual(result.returncode, 0)
                self.assertIn("basenames must be unique", result.stderr)

    def test_missing_directory_symlink_and_unsafe_asset_names_are_rejected(self):
        spaced = self.base / "bad filename.zip"
        spaced.write_bytes(b"data")
        link = self.base / "link.zip"
        link.symlink_to(self.asset)
        for asset in [self.base / "missing.zip", self.base, link, spaced]:
            with self.subTest(asset=asset):
                self.assertNotEqual(self.run_helper(assets=[asset]).returncode, 0)

    def test_asset_above_git_payload_limit_is_rejected_before_reading_bytes(self):
        large = self.base / "large.zip"
        with large.open("wb") as stream:
            stream.truncate(95 * 1024 * 1024 + 1)
        result = self.run_helper(assets=[large])
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("95 MiB", result.stderr)
        self.assertFalse(self.output.exists())

    def test_existing_output_is_preserved_and_checkout_output_is_rejected(self):
        self.output.mkdir()
        (self.output / "plan.json").write_text("Keep existing user output")
        result = self.run_helper()
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.output / "plan.json").read_text(), "Keep existing user output")
        result = self.run_helper(output=self.repo / "generated-plan")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("outside the checkout", result.stderr)
        self.assertFalse((self.repo / "generated-plan").exists())

    def test_each_plan_gets_a_unique_temporary_branch(self):
        first = self.successful_plan()
        second = self.successful_plan(output=self.base / "second-plan")
        self.assertNotEqual(first["branch"], second["branch"])
        self.assertNotEqual(first["workflow_path"], second["workflow_path"])
        self.assertEqual(self.git("rev-parse", "HEAD"), self.target)

    def test_emitted_job_uploads_and_verifies_selected_files_but_does_not_publish(self):
        plan = self.successful_plan()
        result, state = self.run_generated_job(plan)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(state["uploads"], ["package.zip", "SHA256SUMS"])
        self.assertTrue(state["draft"])
        self.assertIn("Verified upload: package.zip", result.stdout)

    def test_emitted_job_skips_an_identical_previously_uploaded_asset(self):
        plan = self.successful_plan()
        asset = plan["assets"][0]
        existing = [{"name": asset["name"], "size": asset["bytes"], "state": "uploaded",
                     "digest": "sha256:" + asset["sha256"]}]
        result, state = self.run_generated_job(plan, existing=existing)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(state["uploads"], ["SHA256SUMS"])
        self.assertIn("Already verified: package.zip", result.stdout)

    def test_emitted_job_rejects_a_conflicting_remote_asset_without_overwriting(self):
        plan = self.successful_plan()
        existing = [{"name": "package.zip", "size": self.asset.stat().st_size,
                     "state": "uploaded", "digest": "sha256:" + "0" * 64}]
        result, state = self.run_generated_job(plan, existing=existing)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Conflicting existing release asset", result.stderr)
        self.assertEqual(state["uploads"], [])
        self.assertEqual(state["assets"], existing)

    def test_emitted_job_rejects_published_or_changed_releases(self):
        plan = self.successful_plan()
        for arguments in [{"draft": False}, {"target": "f" * 40}, {"tag": "v9.9.9"}]:
            with self.subTest(arguments=arguments):
                result, state = self.run_generated_job(plan, **arguments)
                self.assertNotEqual(result.returncode, 0)
                self.assertIn("no longer the intended draft/commit", result.stderr)
                self.assertEqual(state["uploads"], [])

    def test_emitted_job_checks_local_integrity_before_any_upload(self):
        plan = self.successful_plan()
        result, state = self.run_generated_job(plan, corrupt_payload=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("FAILED", result.stdout)
        self.assertEqual(state["uploads"], [])


if __name__ == "__main__":
    unittest.main()
